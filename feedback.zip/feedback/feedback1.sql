﻿CREATE TABLE [dbo].[feedback1] (
    [Name]       VARCHAR (50) NOT NULL,
    [Email]      VARCHAR (50) NULL,
    [ContactNo]  VARCHAR (50) NULL,
    [Suggestion] VARCHAR (50) NULL,
    CONSTRAINT [PK_feedback1] PRIMARY KEY CLUSTERED ([Name] ASC)
);

